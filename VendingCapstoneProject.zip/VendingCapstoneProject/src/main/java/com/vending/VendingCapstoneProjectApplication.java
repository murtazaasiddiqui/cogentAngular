package com.vending;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@ComponentScan("com.vending.controller,com.vending.model")

public class VendingCapstoneProjectApplication 
{
    public static void main( String[] args ) {
    	SpringApplication.run(VendingCapstoneProjectApplication.class, args);
    	
    }
}
