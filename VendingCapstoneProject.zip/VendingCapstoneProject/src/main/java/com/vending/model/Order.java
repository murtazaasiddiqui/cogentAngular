//package com.vending.model;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//@Entity
//@Table(name = "orderDetails")
//public class Order {
//
//	
//	@Id
////	@GeneratedValue(strategy = GenerationType.AUTO)
////	private long id;
//	private float tea;
//	private float blackTea;
//	private float coffee;
//	private float blackCoffee;
//}
