package com.vending.models;

public enum ERole {
	USER, MODERATOR, ADMIN
}
